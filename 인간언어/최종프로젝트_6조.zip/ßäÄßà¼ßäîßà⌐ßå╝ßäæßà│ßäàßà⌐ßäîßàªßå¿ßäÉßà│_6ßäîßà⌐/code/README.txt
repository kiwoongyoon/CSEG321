저희 조의 코드는 다음과 같이 4개로 구성됩니다. 
그 과정을 설명드리면 

1. qa_without_rag.ipynb 파일은 RAG 없이 QA를 진행하여 "rag.csv" 파일을 생성합니다.

2. rag_index_maker.ipynb 파일은 위키피디아 파일을 분리하고 FAISS 인덱스를 생성합니다.

3. qa_with_rag.ipynb 파일은 RAG를 이용하여 FAISS 인덱스를 바탕으로 QA를 진행하여 "no_rag.csv" 파일을 생성합니다.

4. postprocess.ipynb 파일은 두 csv 파일을 합치고, 최종적으로 후처리를 진행하여 submission 파일을 생성합니다.



각 notebook의 파일 경로 정보는 다음과 같습니다.

1. qa_without_rag.ipynb 

open('qa_train.json','r')(cell[2])  : train데이터의 저장된 경로
open('qa_test.json','r')(cell[2])  : test데이터의 저장된 경로 
read_partial_file(cell[2]) : wikipedia.txt의 폴더경로 
df.to_csv('./norag.csv',index=Fasle)(cell[7]) : rag을 사용하지 않은 submission 파일의 저장 경로 



2. rag_index_maker.ipynb

input_file (cell[2]) : 위키피디아 텍스트 파일의 경로
output_dir (cell[2]) : 청킹된 텍스트 파일들이 저장될 폴더의 경로
chunk_dir (cell[3]) : 청킹된 텍스트 파일들이 저장된 폴더의 경로
index_dir (cell[3]) : faiss index 파일들이 저장될 폴더의 경로



3.qa_with_rag.ipynb

tokenizer_path (cell[2]) : tokenizer가 저장된 폴더의 경로
model_path (cell[2]) : 모델이 저장된 폴더의 경로
index_file (cell[3]) : faiss index 파일의 경로
questions_file (cell[3]) : qa_test.json 파일의 경로
text_file (cell[3]) : 청킹된 텍스트 파일의 경로
output_file_path (cell[3]) : submission.csv 파일이 저장될 경로



4. postprocess.ipynb 

pd.read_csv('./norag.csv')(cell[3]) : rag을 사용하지 않은 submission 파일의 저장 경로 
pd.read_csv('./rag.csv'): qa_with_rag.ipynb에서 생성된 submission.csv 파일의 경로 
sub.to_csv('./norag_rag_fill.csv', index=False): 최종적으로 제출할 csv파일의 저장경로 
